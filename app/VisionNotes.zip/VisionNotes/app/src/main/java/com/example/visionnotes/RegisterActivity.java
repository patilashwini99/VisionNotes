package com.example.visionnotes;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {

    TextInputEditText username, password, repassword;
    Button register, goLogin;

    FirebaseAuth auth;
    DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // 🔹 Views
        username = findViewById(R.id.regUsername);
        password = findViewById(R.id.regPassword);
        repassword = findViewById(R.id.regRePassword);
        register = findViewById(R.id.btnRegister);
        goLogin = findViewById(R.id.btnGoLogin);

        // 🔥 Firebase
        auth = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance().getReference("users");

        // 🔥 Register
        register.setOnClickListener(v -> {

            String userInput = username.getText().toString().trim().toLowerCase();

            String user = userInput.replaceAll("\\s+", "")
                    .replaceAll("[^a-z0-9]", "");  //

            String pass = password.getText().toString().trim();
            String repass = repassword.getText().toString().trim();

            // ✅ Empty
            if(user.isEmpty() || pass.isEmpty() || repass.isEmpty()){
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // ✅ Password length
            if(pass.length() < 6){
                Toast.makeText(this, "Password min 6 chars", Toast.LENGTH_SHORT).show();
                return;
            }

            // ✅ Match
            if(!pass.equals(repass)){
                Toast.makeText(this, "Passwords not matching", Toast.LENGTH_SHORT).show();
                return;
            }

            // 🔥 Check username exists
            checkUsernameExists(user, exists -> {

                if(exists){
                    Toast.makeText(this, "Username already taken ❌", Toast.LENGTH_SHORT).show();
                } else {

                    String email = user + "@gmail.com";
                    // 🔥 Create account
                    auth.createUserWithEmailAndPassword(email, pass)
                            .addOnCompleteListener(task -> {

                                if(task.isSuccessful()){

                                    String userId = auth.getCurrentUser().getUid();

                                    // 🔹 Save user data
                                    HashMap<String, Object> map = new HashMap<>();
                                    map.put("username", user);
                                    map.put("createdAt", System.currentTimeMillis());

                                    database.child(userId).setValue(map);

                                    Toast.makeText(this, "Registered ✅", Toast.LENGTH_SHORT).show();

                                    startActivity(new Intent(this, LoginActivity.class));
                                    finish();

                                } else {
                                    Toast.makeText(this,
                                            "Error: " + task.getException().getMessage(),
                                            Toast.LENGTH_LONG).show();
                                }
                            });
                }
            });
        });

        // 🔹 Go Login
        goLogin.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    // 🔥 CHECK USERNAME EXISTS (IMPORTANT)
    private void checkUsernameExists(String username, UsernameCallback callback){

        database.orderByChild("username")
                .equalTo(username)
                .addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        callback.onResult(snapshot.exists());
                    }

                    @Override
                    public void onCancelled(DatabaseError error) {
                        callback.onResult(false);
                    }
                });
    }

    // 🔥 Callback interface
    interface UsernameCallback {
        void onResult(boolean exists);
    }
}